'use strict';

module.exports = require('nested-target-via-alias');
