'use strict';

module.exports = require('nested-leaf-via-alias');
