module.exports = {
  name: '@test/mvnpm-package',
  version: '1.0.0',
  hello: function () {
    return 'Hello from @test/mvnpm-package';
  }
};
