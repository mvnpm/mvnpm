# @test/mvnpm-package

Minimal npm package for testing mvnpm / web-bundler integration.

Expected Maven coordinates:

- groupId: `org.mvnpm.at.test`
- artifactId: `mvnpm-package`
- version: `1.0.0`
